from src.pipeline import IoTPipeline
if __name__ == '__main__': IoTPipeline().run()