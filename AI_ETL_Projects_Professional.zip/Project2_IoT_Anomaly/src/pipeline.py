from sklearn.ensemble import IsolationForest
class IoTPipeline:
    def run(self): print('Detecting anomalies...')