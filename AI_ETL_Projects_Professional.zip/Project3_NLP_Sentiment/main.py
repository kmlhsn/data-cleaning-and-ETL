from src.nlp_cleaner import NLPCleaner
if __name__ == '__main__': NLPCleaner().process()