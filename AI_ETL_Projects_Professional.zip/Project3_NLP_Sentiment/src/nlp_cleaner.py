from textblob import TextBlob
class NLPCleaner:
    def process(self): print('Analyzing sentiment...')