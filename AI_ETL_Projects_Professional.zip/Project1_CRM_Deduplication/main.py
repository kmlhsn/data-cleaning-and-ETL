from src.extractor import DataExtractor
print('Project 1 Running...')