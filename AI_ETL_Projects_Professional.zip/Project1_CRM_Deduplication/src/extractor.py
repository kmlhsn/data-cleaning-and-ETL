import pandas as pd
class DataExtractor:
    def extract(self, path): return pd.read_csv(path)