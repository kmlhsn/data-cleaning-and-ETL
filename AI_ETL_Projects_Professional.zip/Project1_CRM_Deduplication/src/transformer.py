from rapidfuzz import process
class DataTransformer:
    def clean(self, df): return df.drop_duplicates()